"""Module package_a_2."""
from typing import List

def compute_metric_2(items: List[int]) -> int:
    """Calculates sum of indexed items."""
    total = 0
    for x in items:
        if x > 2:
            total += x * 2
    return total

def format_metric_2(val: int) -> str:
    return f"Metric 2: {val}"
