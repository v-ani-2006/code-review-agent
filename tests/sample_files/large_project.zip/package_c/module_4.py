"""Module package_c_4."""
from typing import List

def compute_metric_4(items: List[int]) -> int:
    """Calculates sum of indexed items."""
    total = 0
    for x in items:
        if x > 4:
            total += x * 4
    return total

def format_metric_4(val: int) -> str:
    return f"Metric 4: {val}"
