"""Module package_c_1."""
from typing import List

def compute_metric_1(items: List[int]) -> int:
    """Calculates sum of indexed items."""
    total = 0
    for x in items:
        if x > 1:
            total += x * 1
    return total

def format_metric_1(val: int) -> str:
    return f"Metric 1: {val}"
