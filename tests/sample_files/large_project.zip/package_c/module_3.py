"""Module package_c_3."""
from typing import List

def compute_metric_3(items: List[int]) -> int:
    """Calculates sum of indexed items."""
    total = 0
    for x in items:
        if x > 3:
            total += x * 3
    return total

def format_metric_3(val: int) -> str:
    return f"Metric 3: {val}"
