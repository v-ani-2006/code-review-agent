# Large Project Suite
Multi-module architecture benchmark.
